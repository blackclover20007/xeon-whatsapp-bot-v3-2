module.exports = {
  // Bot identity
  BOT_NAME: "XEXO",
  OWNER_NAME: "yamisaint",
  OWNER_NUMBER: "263784970429",
  OWNER_TELEGRAM: "@saintbypass",
  OWNER_CHANNEL: "https://whatsapp.com/channel/0029Vb9VrNQKbYMGK2la9F1q",
  OWNER_TG_LINK: "https://t.me/sourcecodemarket666",
  OWNER_GITHUB: "https://github.com/blackclover20007",

  // Shown as thumbnail when bot connects (sent to owner on login)
  CONNECT_PIC: "https://www.image2url.com/r2/default/images/1790872649903-cd52d983-a7d2-48ef-9892-655395768334.jpg",

  // Leave blank — bot will ask for it interactively on first run
  PAIRING_NUMBER: "",

  // Force pair-code login (recommended)
  USE_PAIRING_CODE: true,

  // Browser fingerprint shown in Linked Devices
  BROWSER: ["Ubuntu", "Chrome", "20.0.04"],

  // Optional default target (country code + digits, no +)
  DEFAULT_TARGET: "",

  // Owner JIDs — bot restricts crash commands to these numbers
  OWNERS: ["263784970429"],

  // Session folder
  SESSION_DIR: "./auth_xeon",

  // Command prefix
  PREFIX: ".",

  LOG_LEVEL: "silent"
};
